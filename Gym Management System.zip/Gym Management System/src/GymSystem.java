import java.util.*;
import java.io.*;

// ===== Base User =====
abstract class User implements Serializable {
    String id, name, email, password;

    User(String id, String name, String email, String password) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    abstract void showSpecificMenu();
}

// ===== Member =====
class Member extends User {
    String coursetype;
    double planPrice;
    boolean paymentDue;

    Member(String id, String name, String email, String password, String coursetype, double planPrice) {
        super(id, name, email, password);
        this.coursetype = coursetype;
        this.planPrice = planPrice;
        this.paymentDue = true;
    }

    void showSpecificMenu() {
        System.out.println("\n=== MEMBER MENU ===\n");
        System.out.println("Welcome " + name + "!");
        System.out.println("Plan: " + coursetype + " ($" + planPrice + ")");
        System.out.println("Payment: " + (paymentDue ? "DUE" : "PAID"));
        System.out.println("1. Make Payment  2. View Profile  3. Logout");
    }
}

// ===== Trainer =====
class Trainer extends User {
    int maxClients;
    int currentClients;
    ArrayList<String> clientList;

    Trainer(String id, String name, String email, String password, int maxClients) {
        super(id, name, email, password);
        this.maxClients = maxClients;
        this.currentClients = 0;
        this.clientList = new ArrayList<>();
    }

    void showSpecificMenu() {
        System.out.println("\n=== TRAINER MENU ===\n");
        System.out.println("Welcome " + name + "!");
        System.out.println("Clients: " + currentClients + "/" + maxClients);
        System.out.println("1. View Clients  2. View Profile  3. Logout");
    }
}

// ===== Admin =====
class Admin extends User {
    Admin(String id, String name, String password) {
        super(id, name, "", password);
    }

    void showSpecificMenu() {
        System.out.println("\n=== ADMIN MENU ===\n");
        System.out.println("1. Add Member  2. View Members  3. Edit Member  4. Delete Member");
        System.out.println("5. Add Trainer  6. View Trainers  7. Edit Trainer  8. Delete Trainer");
        System.out.println("9. Assign Trainer  10. Logout");
    }
}

// ===== Main System =====
public class GymSystem {
    ArrayList<Member> members;
    ArrayList<Trainer> trainers;
    ArrayList<Admin> admins;
    Scanner scanner = new Scanner(System.in);
    String currentUserType = "";
    String currentUserId = "";

    public GymSystem() {
        loadData();
        if (admins.isEmpty()) {
            admins.add(new Admin("admin", "Administrator", "admin"));
        }
    }

    // ===== Persistence =====
    void loadData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("gymdata.ser"))) {
            members = (ArrayList<Member>) ois.readObject();
            trainers = (ArrayList<Trainer>) ois.readObject();
            admins = (ArrayList<Admin>) ois.readObject();
        } catch (Exception e) {
            members = new ArrayList<>();
            trainers = new ArrayList<>();
            admins = new ArrayList<>();
        }
    }

    void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("gymdata.ser"))) {
            oos.writeObject(members);
            oos.writeObject(trainers);
            oos.writeObject(admins);
        } catch (Exception e) {
            System.out.println("Error saving data!");
        }
    }

    // ===== Start =====
    public void start() {
//        System.out.println("\n=== GYM MANAGEMENT SYSTEM ===");
        while (true) {
            if (currentUserType.equals("")) {
                showLoginMenu();
            } else if (currentUserType.equals("ADMIN")) {
                showAdminMenu();
            } else if (currentUserType.equals("MEMBER")) {
                showMemberMenu();
            } else if (currentUserType.equals("TRAINER")) {
                showTrainerMenu();
            }
        }
    }

    // ===== Login Menu =====
    void showLoginMenu() {
        System.out.println("\n=== GYM MANAGEMENT SYSTEM ===");
        System.out.println("\n1. Admin  2. Member  3. Trainer  4. Exit");
        System.out.print("Choose: ");
        int choice = getInt();

        if (choice == 4) {
            System.out.println("Goodbye!");
            saveData();
            System.exit(0);
        }

        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        User user = null;
        if (choice == 1) user = findAdmin(id);
        else if (choice == 2) user = findMember(id);
        else if (choice == 3) user = findTrainer(id);

        if (user != null && user.password.equals(password)) {
            if (choice == 1) currentUserType = "ADMIN";
            else if (choice == 2) currentUserType = "MEMBER";
            else currentUserType = "TRAINER";
            currentUserId = id;
            System.out.println(currentUserType.charAt(0) + currentUserType.substring(1).toLowerCase() + " logged in!");
        } else {
            System.out.println("Invalid login!");
        }
    }

    // ===== Menus =====
    void showAdminMenu() {
        findAdmin(currentUserId).showSpecificMenu();
        System.out.print("Choose: ");
        switch (getInt()) {
            case 1: addMember(); break;
            case 2: viewMembers(); break;
            case 3: editMember(); break;
            case 4: deleteMember(); break;
            case 5: addTrainer(); break;
            case 6: viewTrainers(); break;
            case 7: editTrainer(); break;
            case 8: deleteTrainer(); break;
            case 9: assignTrainer(); break;
            case 10: logout(); break;
        }
    }

    void showMemberMenu() {
        findMember(currentUserId).showSpecificMenu();
        System.out.print("Choose: ");
        switch (getInt()) {
            case 1: makePayment(); break;
            case 2: viewProfile(); break;
            case 3: logout(); break;
        }
    }

    void showTrainerMenu() {
        findTrainer(currentUserId).showSpecificMenu();
        System.out.print("Choose: ");
        switch (getInt()) {
            case 1: viewClients(); break;
            case 2: viewProfile(); break;
            case 3: logout(); break;
        }
    }

    // ===== CRUD for Members =====
    void addMember() {
        System.out.print("Member ID: ");
        String id = scanner.nextLine();
        if (findMember(id) != null) {
            System.out.println("ID exists!");
            return;
        }

        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        System.out.println("Plan: 1.Basic($50)  2.Premium($100)  3.VIP($200)");
        System.out.print("Choose: ");

        int plan = getInt();
        String planType = "";
        double price = 0;
        if (plan == 1) { planType = "Basic"; price = 50; }
        else if (plan == 2) { planType = "Premium"; price = 100; }
        else if (plan == 3) { planType = "VIP"; price = 200; }
        else { System.out.println("Invalid plan!"); return; }

        members.add(new Member(id, name, email, password, planType, price));
        saveData();
        System.out.println("Member added!");
    }

    void editMember() {
        System.out.print("Member ID: ");
        String id = scanner.nextLine();
        Member m = findMember(id);
        if (m == null) {
            System.out.println("Member not found!");
            return;
        }

        System.out.println("1.Name  2.Email  3.Password  4.Plan");
        System.out.print("Edit: ");
        switch (getInt()) {
            case 1: System.out.print("New name: "); m.name = scanner.nextLine(); break;
            case 2: System.out.print("New email: "); m.email = scanner.nextLine(); break;
            case 3: System.out.print("New password: "); m.password = scanner.nextLine(); break;
            case 4:
                System.out.println("1.Basic($50)  2.Premium($100)  3.VIP($200)");
                int plan = getInt();
                if (plan == 1) { m.coursetype = "Basic"; m.planPrice = 50; }
                else if (plan == 2) { m.coursetype = "Premium"; m.planPrice = 100; }
                else if (plan == 3) { m.coursetype = "VIP"; m.planPrice = 200; }
                break;
        }
        saveData();
        System.out.println("Updated!");
    }

    void deleteMember() {
        System.out.print("Member ID: ");
        String id = scanner.nextLine();
        Member member = findMember(id);
        if (member == null) {
            System.out.println("Member not found!");
            return;
        }
        System.out.print("Confirm delete (y/n): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) {
            for (Trainer t : trainers) {
                if (t.clientList.contains(id)) {
                    t.clientList.remove(id);
                    t.currentClients--;
                }
            }
            members.remove(member);
            saveData();
            System.out.println("Member deleted!");
        }
    }

    void viewMembers() {
        if (members.isEmpty()) {
            System.out.println("No members!");
            return;
        }
        for (Member m : members) {
            System.out.println("ID: " + m.id + " | Name: " + m.name +
                    " | Plan: " + m.coursetype +
                    " | Payment: " + (m.paymentDue ? "DUE" : "PAID"));
        }
    }

    // ===== CRUD for Trainers =====
    void addTrainer() {
        System.out.print("Trainer ID: ");
        String id = scanner.nextLine();
        if (findTrainer(id) != null) {
            System.out.println("ID exists!");
            return;
        }

        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        System.out.print("Max Clients: ");
        int maxClients = getInt();

        trainers.add(new Trainer(id, name, email, password, maxClients));
        saveData();
        System.out.println("Trainer added!");
    }

    void editTrainer() {
        System.out.print("Trainer ID: ");
        String id = scanner.nextLine();
        Trainer t = findTrainer(id);
        if (t == null) {
            System.out.println("Trainer not found!");
            return;
        }

        System.out.println("1.Name  2.Email  3.Password  4.Max Clients");
        System.out.print("Edit: ");
        switch (getInt()) {
            case 1: System.out.print("New name: "); t.name = scanner.nextLine(); break;
            case 2: System.out.print("New email: "); t.email = scanner.nextLine(); break;
            case 3: System.out.print("New password: "); t.password = scanner.nextLine(); break;
            case 4:
                System.out.print("New max clients: ");
                int max = getInt();
                if (max >= t.currentClients) t.maxClients = max;
                else System.out.println("Cannot be less than current clients!");
                break;
        }
        saveData();
        System.out.println("Updated!");
    }

    void deleteTrainer() {
        System.out.print("Trainer ID: ");
        String id = scanner.nextLine();
        Trainer trainer = findTrainer(id);
        if (trainer == null) {
            System.out.println("Trainer not found!");
            return;
        }
        System.out.print("Confirm delete (y/n): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) {
            trainers.remove(trainer);
            saveData();
            System.out.println("Trainer deleted!");
        }
    }

    void viewTrainers() {
        if (trainers.isEmpty()) {
            System.out.println("No trainers!");
            return;
        }
        for (Trainer t : trainers) {
            System.out.println("ID: " + t.id + " | Name: " + t.name +
                    " | Clients: " + t.currentClients + "/" + t.maxClients);
        }
    }

    // ===== Assign Trainer =====
    void assignTrainer() {
        System.out.print("Member ID: ");
        String memberId = scanner.nextLine();
        System.out.print("Trainer ID: ");
        String trainerId = scanner.nextLine();

        Member member = findMember(memberId);
        Trainer trainer = findTrainer(trainerId);

        if (member == null || trainer == null) {
            System.out.println("Member or Trainer not found!");
            return;
        }
        if (trainer.currentClients >= trainer.maxClients) {
            System.out.println("Trainer full!");
            return;
        }
        trainer.clientList.add(memberId);
        trainer.currentClients++;
        saveData();
        System.out.println("Trainer assigned!");
    }

    // ===== Member Actions =====
    void makePayment() {
        Member member = findMember(currentUserId);
        if (!member.paymentDue) {
            System.out.println("No payment due!");
            return;
        }
        System.out.println("Amount: $" + member.planPrice);
        System.out.println("1.Cash  2.Card  3.Mobile");
        System.out.print("Method: ");
        int method = getInt();
        if (method >= 1 && method <= 3) {
            member.paymentDue = false;
            saveData();
            System.out.println("Payment successful!");
        }
    }

    void viewProfile() {
        if (currentUserType.equals("MEMBER")) {
            Member m = findMember(currentUserId);
            System.out.println("ID: " + m.id + " | Name: " + m.name +
                    " | Email: " + m.email + " | Plan: " + m.coursetype);
        } else if (currentUserType.equals("TRAINER")) {
            Trainer t = findTrainer(currentUserId);
            System.out.println("ID: " + t.id + " | Name: " + t.name +
                    " | Email: " + t.email + " | Max Clients: " + t.maxClients);
        }
    }

    void viewClients() {
        Trainer trainer = findTrainer(currentUserId);
        if (trainer.clientList.isEmpty()) {
            System.out.println("No clients!");
            return;
        }
        for (String memberId : trainer.clientList) {
            Member m = findMember(memberId);
            if (m != null) {
                System.out.println("ID: " + m.id + " | Name: " + m.name +
                        " | Plan: " + m.coursetype);
            }
        }
    }

    // ===== Helpers =====
    void logout() {
        currentUserType = "";
        currentUserId = "";
        saveData();
        System.out.println("Logged out!");
    }

    Member findMember(String id) {
        for (Member member : members) if (member.id.equals(id)) return member;
        return null;
    }

    Trainer findTrainer(String id) {
        for (Trainer trainer : trainers) if (trainer.id.equals(id)) return trainer;
        return null;
    }

    Admin findAdmin(String id) {
        for (Admin admin : admins) if (admin.id.equals(id)) return admin;
        return null;
    }

    int getInt() {
        try {
            int result = scanner.nextInt();
            scanner.nextLine();
            return result;
        } catch (Exception e) {
            scanner.nextLine();
            return -1;
        }
    }

    // ===== Main =====
    public static void main(String[] args) {
        new GymSystem().start();
    }
}
